<?php
$page_title = "Sign Up";
require_once 'includes/header.php';

if (is_logged_in()) {
    header("Location: dashboard.php");
    exit();
}

// Initialize error array
$errors = [];

// Handle signup form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['signup'])) {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    $confirm_password = sanitize($_POST['confirm_password']);
    $full_name = sanitize($_POST['full_name']);
    $security_question = sanitize($_POST['security_question']);
    $security_answer = sanitize($_POST['security_answer']);

    // Validate inputs
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($full_name)) {
        $errors[] = "All fields are required";
    }

    if (!is_valid_email($email)) {
        $errors[] = "Invalid email format";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    if (empty($security_question) || empty($security_answer)) {
        $errors[] = "Security question and answer are required";
    }

    // Check if username or email already exists
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);

            if ($stmt->rowCount() > 0) {
                $errors[] = "Username or email already exists";
            }
        } catch (PDOException $e) {
            $errors[] = "Error checking user existence: " . $e->getMessage();
        }
    }

    if (empty($errors)) {
        // Hash password and security answer
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $hashed_security_answer = password_hash($security_answer, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, security_question, security_answer) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $email, $hashed_password, $full_name, $security_question, $hashed_security_answer]);

            set_message('Account created successfully. Please login.', 'success');
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $errors[] = 'Error creating account: ' . $e->getMessage();
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow">
            <div class="card-body">
                <h2 class="card-title text-center mb-4">Create an Account</h2>

                <!-- Display error messages -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username"
                                value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name"
                            value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="security_question" class="form-label">Security Question</label>
                        <select class="form-select" id="security_question" name="security_question" required>
                            <option value="">Select a security question</option>
                            <option value="What was your first pet's name?" <?php echo (isset($_POST['security_question']) && $_POST['security_question'] === "What was your first pet's name?") ? 'selected' : ''; ?>>What was your first pet's name?</option>
                            <option value="What is your mother's maiden name?" <?php echo (isset($_POST['security_question']) && $_POST['security_question'] === "What is your mother's maiden name?") ? 'selected' : ''; ?>>What is your mother's maiden name?</option>
                            <option value="What city were you born in?" <?php echo (isset($_POST['security_question']) && $_POST['security_question'] === "What city were you born in?") ? 'selected' : ''; ?>>What city were you born in?</option>
                            <option value="What is your favorite book?" <?php echo (isset($_POST['security_question']) && $_POST['security_question'] === "What is your favorite book?") ? 'selected' : ''; ?>>What is your favorite book?</option>
                            <option value="What was the name of your first school?" <?php echo (isset($_POST['security_question']) && $_POST['security_question'] === "What was the name of your first school?") ? 'selected' : ''; ?>>What was the name of your first school?</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="security_answer" class="form-label">Security Answer</label>
                        <input type="text" class="form-control" id="security_answer" name="security_answer"
                            value="<?php echo isset($_POST['security_answer']) ? htmlspecialchars($_POST['security_answer']) : ''; ?>" required>
                    </div>

                    <div class="d-grid mb-3">
                        <button type="submit" name="signup" class="btn btn-primary">Sign Up</button>
                    </div>

                    <div class="text-center">
                        <p>Already have an account? <a href="index.php" class="text-decoration-none">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>