<?php
$page_title = "Manage Users";
require_once 'includes/header.php';
require_admin();

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_user'])) {
    if (!validate_csrf_token($_POST['csrf_token'])) {
        set_message('Invalid CSRF token', 'danger');
        header("Location: manage-users.php");
        exit();
    }

    $user_id = (int)$_POST['user_id'];

    try {
        // Get username for logging before deletion
        $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if ($user) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND is_admin = FALSE");
            $stmt->execute([$user_id]);

            log_activity("User deleted: " . $user['username']);
            set_message('User deleted successfully', 'success');
        }
    } catch (PDOException $e) {
        set_message('Error deleting user: ' . $e->getMessage(), 'danger');
    }

    header("Location: manage-users.php");
    exit();
}

// Get filter parameters (sanitize all inputs)
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$email_filter = isset($_GET['email']) ? sanitize($_GET['email']) : '';
$start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : '';

// Pagination and sorting settings
$per_page = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Sorting parameters
$sort_column = $_GET['sort'] ?? 'created_at';
$sort_order = $_GET['order'] ?? 'DESC';

// Validate sort column to prevent SQL injection
$valid_columns = ['username', 'email', 'full_name', 'created_at'];
if (!in_array($sort_column, $valid_columns)) {
    $sort_column = 'created_at';
}

// Validate sort order
$sort_order = strtoupper($sort_order) === 'ASC' ? 'ASC' : 'DESC';

// Build query dynamically
$query = "SELECT id, username, email, full_name, created_at FROM users WHERE is_admin = FALSE";
$count_query = "SELECT COUNT(*) FROM users WHERE is_admin = FALSE";
$params = [];
$count_params = [];

// Search by username or full_name
if (!empty($search)) {
    $query .= " AND (username LIKE ? OR full_name LIKE ?)";
    $count_query .= " AND (username LIKE ? OR full_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
}

// Filter by email (partial match)
if (!empty($email_filter)) {
    $query .= " AND email LIKE ?";
    $count_query .= " AND email LIKE ?";
    $params[] = "%$email_filter%";
    $count_params[] = "%$email_filter%";
}

// Filter by date range
if (!empty($start_date)) {
    $query .= " AND created_at >= ?";
    $count_query .= " AND created_at >= ?";
    $params[] = $start_date . " 00:00:00";
    $count_params[] = $start_date . " 00:00:00";
}
if (!empty($end_date)) {
    $query .= " AND created_at <= ?";
    $count_query .= " AND created_at <= ?";
    $params[] = $end_date . " 23:59:59";
    $count_params[] = $end_date . " 23:59:59";
}

$query .= " ORDER BY $sort_column $sort_order LIMIT $per_page OFFSET $offset";

// Fetch users
try {
    // Get total count for pagination
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($count_params);
    $total_users = $stmt->fetchColumn();

    // Calculate total pages
    $total_pages = ceil($total_users / $per_page);

    // Get users for current page
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    set_message('Error fetching users: ' . $e->getMessage(), 'danger');
    $users = [];
    $total_users = 0;
    $total_pages = 1;
}

// Function to generate sort link
function sort_link($column, $label)
{
    global $sort_column, $sort_order, $search, $email_filter, $start_date, $end_date, $per_page;

    $new_order = ($sort_column === $column && $sort_order === 'DESC') ? 'ASC' : 'DESC';
    $query_params = [
        'search' => $search,
        'email' => $email_filter,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'per_page' => $per_page,
        'sort' => $column,
        'order' => $new_order
    ];

    $sort_icon = '';
    if ($sort_column === $column) {
        $sort_icon = $sort_order === 'ASC' ? ' <i class="fas fa-sort-up"></i>' : ' <i class="fas fa-sort-down"></i>';
    } else {
        $sort_icon = ' <i class="fas fa-sort"></i>';
    }

    return '<a href="?' . http_build_query($query_params) . '" class="text-decoration-none">' . $label . $sort_icon . '</a>';
}
?>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-3">Manage Users</h5>
                <form method="get" class="row g-3 align-items-end">
                    <div class="col-md-2 col-sm-6">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" name="search" id="search" class="form-control" placeholder="Username/Name"
                            value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" name="email" id="email" class="form-control" placeholder="Email"
                            value="<?php echo htmlspecialchars($email_filter); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="start_date" class="form-label">From Date</label>
                        <input type="date" name="start_date" id="start_date" class="form-control"
                            value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="end_date" class="form-label">To Date</label>
                        <input type="date" name="end_date" id="end_date" class="form-control"
                            value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="per_page" class="form-label">Per Page</label>
                        <select name="per_page" id="per_page" class="form-select">
                            <option value="5" <?php echo $per_page == 5 ? 'selected' : ''; ?>>5</option>
                            <option value="10" <?php echo $per_page == 10 ? 'selected' : ''; ?>>10</option>
                            <option value="15" <?php echo $per_page == 15 ? 'selected' : ''; ?>>15</option>
                            <option value="20" <?php echo $per_page == 20 ? 'selected' : ''; ?>>20</option>
                            <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <?php if (empty($users)): ?>
                    <div class="alert alert-info">
                        No users found matching your criteria.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo sort_link('username', 'Username'); ?></th>
                                    <th><?php echo sort_link('email', 'Email'); ?></th>
                                    <th><?php echo sort_link('full_name', 'Full Name'); ?></th>
                                    <th><?php echo sort_link('created_at', 'Joined'); ?></th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <form action="manage-users.php" method="post" onsubmit="return confirm('Are you sure you want to delete this user? This will also delete all their tasks.');">
                                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" name="delete_user" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="User pagination">
                            <ul class="pagination justify-content-center mt-3">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>"
                                            aria-label="First">
                                            <span aria-hidden="true">&laquo;&laquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>"
                                            aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                // Show page numbers
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);

                                for ($i = $start_page; $i <= $end_page; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>"
                                            aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"
                                            aria-label="Last">
                                            <span aria-hidden="true">&raquo;&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>

                    <div class="text-muted text-center">
                        Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + $per_page, $total_users); ?> of <?php echo $total_users; ?> users
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>