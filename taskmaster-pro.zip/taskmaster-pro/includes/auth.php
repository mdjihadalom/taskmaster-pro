<?php
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
function is_logged_in()
{
    return isset($_SESSION['user_id']);
}

// Check if user is admin
function is_admin()
{
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

// Redirect if not logged in
function require_login()
{
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header("Location: signup.php");
        exit();
    }
}

// Redirect if not admin
function require_admin()
{
    require_login();
    if (!is_admin()) {
        set_message('Access denied: Admin privileges required', 'danger');
        header("Location: dashboard.php");
        exit();
    }
}

// CSRF token generation and validation
function generate_csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validate_csrf_token($token)
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Log activity
function log_activity($activity)
{
    global $pdo;
    $ip_address = $_SERVER['REMOTE_ADDR'];

    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, activity, ip_address) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $activity, $ip_address]);
}
