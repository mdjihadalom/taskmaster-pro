<?php
require_once 'config.php';

// Set flash message
function set_message($message, $type = 'success')
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

// Display flash message
function display_message()
{
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'success';

        echo "<div class='alert alert-$type alert-dismissible fade show' role='alert'>";
        echo htmlspecialchars($message);
        echo "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>";
        echo "</div>";

        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
    }
}

// Sanitize input data
function sanitize($data)
{
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Validate email
function is_valid_email($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Generate random token for password reset
function generate_token($length = 32)
{
    return bin2hex(random_bytes($length));
}

// Get current user's ID
function get_current_user_id()
{
    return $_SESSION['user_id'] ?? null;
}
