            </main>

            <footer class="bg-primary text-white py-4 mt-4">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <h5><?php echo APP_NAME; ?></h5>
                            <p>A task management application to organize your daily tasks efficiently.</p>
                        </div>
                        <div class="col-md-4">
                            <h5>Contact Us</h5>
                            <ul class="list-unstyled">
                                <li>
                                    <i class="fas fa-envelope me-2"></i>
                                    <a href="mailto:jihadalom191@gmail.com" class="text-decoration-none text-white">
                                        support@taskmasterpro.com
                                    </a>
                                </li>
                                <li>
                                    <i class="fas fa-phone me-2"></i>
                                    <a href="tel:+8801795592137" class="text-decoration-none text-white">
                                        +880-1795-592137
                                    </a>
                                </li>
                            </ul>
                        </div>

                    </div>
                    <hr>
                    <div class="text-center">
                        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved. Developed by Md Jihad Alom.</p>
                    </div>
                </div>
            </footer>

            <!-- Bootstrap JS -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

            <!-- Custom JS -->
            <script src="assets/js/main.js"></script>
            </body>

            </html>