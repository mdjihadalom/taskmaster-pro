<?php
$page_title = "View Messages";
require_once 'includes/header.php';
require_admin();

// Handle marking message as read/unread
if (isset($_GET['toggle_status'])) {
    $message_id = (int)$_GET['toggle_status'];

    try {
        // Get current status
        $stmt = $pdo->prepare("SELECT id, status FROM messages WHERE id = ?");
        $stmt->execute([$message_id]);
        $message = $stmt->fetch();

        if ($message) {
            $new_status = $message['status'] === 'read' ? 'unread' : 'read';

            $stmt = $pdo->prepare("UPDATE messages SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $message_id]);

            set_message("Message marked as $new_status", 'success');
        }
    } catch (PDOException $e) {
        set_message('Error updating message status: ' . htmlspecialchars($e->getMessage()), 'danger');
    }

    header("Location: view-messages.php?" . http_build_query($_GET));
    exit;
}

// Handle message deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_message'])) {
    // Validate CSRF token
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('Invalid CSRF token', 'danger');
        header("Location: view-messages.php");
        exit;
    }

    $message_id = (int)$_POST['message_id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM messages WHERE id = ?");
        $stmt->execute([$message_id]);

        set_message('Message deleted successfully', 'success');
    } catch (PDOException $e) {
        set_message('Error deleting message: ' . htmlspecialchars($e->getMessage()), 'danger');
    }

    header("Location: view-messages.php?" . http_build_query($_GET));
    exit;
}

// Get filter and search parameters
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : '';

// Pagination settings
$per_page = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Build query based on filter and search
$query = "SELECT * FROM messages";
$count_query = "SELECT COUNT(*) FROM messages";
$params = [];
$count_params = [];

// Add WHERE clause if needed
$where_added = false;

if ($filter === 'read') {
    $query .= " WHERE status = 'read'";
    $count_query .= " WHERE status = 'read'";
    $where_added = true;
} elseif ($filter === 'unread') {
    $query .= " WHERE status = 'unread'";
    $count_query .= " WHERE status = 'unread'";
    $where_added = true;
}

if (!empty($search)) {
    $query .= $where_added ? " AND" : " WHERE";
    $query .= " (name LIKE ? OR email LIKE ? OR message LIKE ?)";
    $count_query .= $where_added ? " AND" : " WHERE";
    $count_query .= " (name LIKE ? OR email LIKE ? OR message LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $count_params = $params;
    $where_added = true;
}

// Date range filtering
if (!empty($start_date)) {
    $query .= $where_added ? " AND" : " WHERE";
    $query .= " DATE(created_at) >= ?";
    $count_query .= $where_added ? " AND" : " WHERE";
    $count_query .= " DATE(created_at) >= ?";
    $params[] = $start_date;
    $count_params[] = $start_date;
    $where_added = true;
}

if (!empty($end_date)) {
    $query .= $where_added ? " AND" : " WHERE";
    $query .= " DATE(created_at) <= ?";
    $count_query .= $where_added ? " AND" : " WHERE";
    $count_query .= " DATE(created_at) <= ?";
    $params[] = $end_date;
    $count_params[] = $end_date;
}

$query .= " ORDER BY created_at DESC LIMIT $per_page OFFSET $offset";

// Fetch messages
try {
    // Get total count for pagination
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($count_params);
    $total_messages = $stmt->fetchColumn();

    // Calculate total pages
    $total_pages = ceil($total_messages / $per_page);

    // Get messages for current page
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $messages = $stmt->fetchAll();
} catch (PDOException $e) {
    set_message('Error fetching messages: ' . htmlspecialchars($e->getMessage()), 'danger');
    $messages = [];
    $total_messages = 0;
    $total_pages = 1;
}
?>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-3">Contact Messages</h5>
                <form method="get" class="row g-3 align-items-end">
                    <div class="col-md-2 col-sm-6">
                        <label for="filter" class="form-label">Status</label>
                        <select name="filter" id="filter" class="form-select">
                            <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Messages</option>
                            <option value="read" <?php echo $filter === 'read' ? 'selected' : ''; ?>>Read</option>
                            <option value="unread" <?php echo $filter === 'unread' ? 'selected' : ''; ?>>Unread</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="start_date" class="form-label">From Date</label>
                        <input type="date" name="start_date" id="start_date" class="form-control"
                            value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="end_date" class="form-label">To Date</label>
                        <input type="date" name="end_date" id="end_date" class="form-control"
                            value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" name="search" id="search" class="form-control" placeholder="Name, email or message"
                            value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <label for="per_page" class="form-label">Per Page</label>
                        <select name="per_page" id="per_page" class="form-select">
                            <option value="5" <?php echo $per_page == 5 ? 'selected' : ''; ?>>5</option>
                            <option value="10" <?php echo $per_page == 10 ? 'selected' : ''; ?>>10</option>
                            <option value="15" <?php echo $per_page == 15 ? 'selected' : ''; ?>>15</option>
                            <option value="20" <?php echo $per_page == 20 ? 'selected' : ''; ?>>20</option>
                            <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-6">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <?php if (empty($messages)): ?>
                    <div class="alert alert-info">
                        No messages found matching your criteria.
                    </div>
                <?php else: ?>
                    <div class="list-group">
                        <?php foreach ($messages as $message): ?>
                            <div class="list-group-item <?php echo $message['status'] === 'unread' ? 'list-group-item-primary' : ''; ?>">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="mb-1">
                                            <?php echo htmlspecialchars($message['name']); ?> ||
                                            <small class="text-muted"><?php echo htmlspecialchars($message['email']); ?></small>
                                        </h6>
                                        <small class="text-muted">Sent: <?php echo date('M j, Y g:i A', strtotime($message['created_at'])); ?></small>
                                    </div>
                                    <div>
                                        <a href="view-messages.php?<?php echo http_build_query(array_merge($_GET, ['toggle_status' => $message['id']])); ?>"
                                            class="btn btn-sm btn-<?php echo $message['status'] === 'read' ? 'warning' : 'success'; ?> me-1">
                                            <i class="fas fa-<?php echo $message['status'] === 'read' ? 'envelope' : 'envelope-open'; ?>"></i>
                                            <?php echo ucfirst($message['status']); ?>
                                        </a>
                                        <form action="view-messages.php" method="post" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this message?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="message_id" value="<?php echo (int)$message['id']; ?>">
                                            <button type="submit" name="delete_message" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Message pagination" class="mt-3">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>"
                                            aria-label="First">
                                            <span aria-hidden="true">&laquo;&laquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>"
                                            aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                // Show page numbers
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);

                                for ($i = $start_page; $i <= $end_page; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>"
                                            aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link"
                                            href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"
                                            aria-label="Last">
                                            <span aria-hidden="true">&raquo;&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>

                    <div class="text-muted text-center">
                        Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + $per_page, $total_messages); ?> of <?php echo $total_messages; ?> messages
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>