<?php
$page_title = "Dashboard";
require_once 'includes/header.php';
require_login();
if ($_SESSION['is_admin'] != 0) {
    header("Location: admin-dashboard.php");
    exit();
}

// Get user's tasks count
try {
    $total_tasks_stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ?");
    $total_tasks_stmt->execute([$_SESSION['user_id']]);
    $total_tasks = $total_tasks_stmt->fetchColumn();

    $completed_tasks_stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'completed'");
    $completed_tasks_stmt->execute([$_SESSION['user_id']]);
    $completed_tasks = $completed_tasks_stmt->fetchColumn();

    $pending_tasks_stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'pending'");
    $pending_tasks_stmt->execute([$_SESSION['user_id']]);
    $pending_tasks = $pending_tasks_stmt->fetchColumn();
} catch (PDOException $e) {
    set_message('Error fetching task counts: ' . htmlspecialchars($e->getMessage()), 'danger');
    $total_tasks = $completed_tasks = $pending_tasks = 0;
}

// Get recent tasks
$recent_tasks = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_tasks = $stmt->fetchAll();
} catch (PDOException $e) {
    set_message('Error fetching recent tasks: ' . htmlspecialchars($e->getMessage()), 'danger');
}
?>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Total Tasks</h5>
                        <h2 class="mb-0"><?php echo (int)$total_tasks; ?></h2>
                    </div>
                    <i class="fas fa-tasks fa-3x"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Completed</h5>
                        <h2 class="mb-0"><?php echo (int)$completed_tasks; ?></h2>
                    </div>
                    <i class="fas fa-check-circle fa-3x"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card bg-warning text-dark">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title">Pending</h5>
                        <h2 class="mb-0"><?php echo (int)$pending_tasks; ?></h2>
                    </div>
                    <i class="fas fa-hourglass-half fa-3x"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Recent Tasks</h5>
            </div>
            <div class="card-body">
                <?php if (empty($recent_tasks)): ?>
                    <p class="text-muted">No recent tasks found.</p>
                <?php else: ?>
                    <div class="list-group">
                        <?php foreach ($recent_tasks as $task): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo htmlspecialchars($task['title']); ?></h6>
                                        <small class="text-muted">Created: <?php echo date('M j, Y g:i A', strtotime($task['created_at'])); ?></small>
                                    </div>
                                    <span class="badge bg-<?php echo $task['status'] === 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst(htmlspecialchars($task['status'])); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer text-end">
                <a href="todo.php" class="btn btn-sm btn-primary">View All Tasks</a>
            </div>
        </div>
    </div>

    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="todo.php?action=add" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i> Add New Task
                    </a>
                    <a href="edit-profile.php" class="btn btn-outline-secondary">
                        <i class="fas fa-user-edit me-2"></i> Edit Profile
                    </a>
                    <a href="contact.php" class="btn btn-outline-info">
                        <i class="fas fa-envelope me-2"></i> Contact Support
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>