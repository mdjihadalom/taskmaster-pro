<?php
$page_title = "Edit Profile";
require_once 'includes/header.php';
require_login();

// Handle profile update form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $current_password = sanitize($_POST['current_password']);
    $new_password = sanitize($_POST['new_password']);
    $confirm_password = sanitize($_POST['confirm_password']);

    $errors = [];

    // Validate email
    if (!is_valid_email($email)) {
        $errors[] = "Invalid email format";
    }

    // Check if email is already taken by another user
    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $_SESSION['user_id']]);

        if ($stmt->rowCount() > 0) {
            $errors[] = "Email already taken by another user";
        }
    } catch (PDOException $e) {
        $errors[] = "Error checking email: " . $e->getMessage();
    }

    // Password change validation
    $password_changed = false;
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $errors[] = "Current password is required to change password";
        } else {
            // Verify current password
            try {
                $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $user = $stmt->fetch();

                if (!$user || !password_verify($current_password, $user['password'])) {
                    $errors[] = "Current password is incorrect";
                }
            } catch (PDOException $e) {
                $errors[] = "Error verifying password: " . $e->getMessage();
            }
        }

        if ($new_password !== $confirm_password) {
            $errors[] = "New passwords do not match";
        }

        if (strlen($new_password) < 8) {
            $errors[] = "New password must be at least 8 characters long";
        }

        $password_changed = true;
    }

    if (empty($errors)) {
        try {
            if ($password_changed) {
                // Update with new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, $hashed_password, $_SESSION['user_id']]);

                // Update session email
                $_SESSION['email'] = $email;
                $_SESSION['full_name'] = $full_name;
            } else {
                // Update without password change
                $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, $_SESSION['user_id']]);

                // Update session email
                $_SESSION['email'] = $email;
                $_SESSION['full_name'] = $full_name;
            }

            set_message('Profile updated successfully', 'success');
            header("Location: dashboard.php");
            exit();
        } catch (PDOException $e) {
            set_message('Error updating profile: ' . $e->getMessage(), 'danger');
        }
    } else {
        foreach ($errors as $error) {
            set_message($error, 'danger');
        }
    }
}

// Get current user data
try {
    $stmt = $pdo->prepare("SELECT username, email, full_name FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if (!$user) {
        set_message('User not found', 'danger');
        header("Location: dashboard.php");
        exit();
    }
} catch (PDOException $e) {
    set_message('Error fetching user data: ' . $e->getMessage(), 'danger');
    header("Location: dashboard.php");
    exit();
}
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow">
            <div class="card-body">
                <h2 class="card-title text-center mb-4">Profile</h2>

                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                        <small class="text-muted">Username cannot be changed</small>
                    </div>

                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name"
                            value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email"
                            value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password (required for password change)</label>
                        <input type="password" class="form-control" id="current_password" name="current_password">
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password (leave blank to keep current)</label>
                        <input type="password" class="form-control" id="new_password" name="new_password">
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                    </div>

                    <div class="d-grid mb-3">
                        <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>