<?php
$page_title = "Contact Us";
require_once 'includes/header.php';
require_login();
if ($_SESSION['is_admin'] != 0) {
    header("Location: admin-dashboard.php");
    exit();
}

// Handle contact form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    // CSRF Token Validation
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('Invalid CSRF token. Please try again.', 'danger');
        header("Location: contact.php");
        exit();
    }

    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $message = sanitize($_POST['message']);

    // Validate inputs
    $errors = [];

    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (!is_valid_email($email)) {
        $errors[] = "Invalid email format";
    }

    if (empty($message)) {
        $errors[] = "Message is required";
    }

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $message]);

            set_message('Your message has been sent successfully', 'success');
            header("Location: contact.php");
            exit();
        } catch (PDOException $e) {
            set_message('Error sending message: ' . $e->getMessage(), 'danger');
        }
    } else {
        foreach ($errors as $error) {
            set_message($error, 'danger');
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow">
            <div class="card-body">
                <h2 class="card-title text-center mb-4">Contact Us</h2>
                <p class="text-center mb-4">Have questions or feedback? Send us a message and we'll get back to you as soon as possible.</p>

                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : htmlspecialchars($_SESSION['full_name']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email"
                            value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : htmlspecialchars($_SESSION['email']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required><?php
                                                                                                        echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '';
                                                                                                        ?></textarea>
                    </div>

                    <div class="d-grid">
                        <button type="submit" name="send_message" class="btn btn-primary">Send Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>