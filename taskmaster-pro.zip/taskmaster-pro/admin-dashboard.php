<?php
$page_title = "Admin Dashboard";
require_once 'includes/header.php';
require_admin();

// Handle filters
$username_filter = $_GET['username'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

// Pagination and sorting settings
$per_page = $_GET['per_page'] ?? 5; 
$page = $_GET['page'] ?? 1; 
$offset = ($page - 1) * $per_page;

// Sorting parameters
$sort_column = $_GET['sort'] ?? 'created_at';
$sort_order = $_GET['order'] ?? 'DESC';

// Validate sort column to prevent SQL injection
$valid_columns = ['username', 'activity', 'ip_address', 'created_at'];
if (!in_array($sort_column, $valid_columns)) {
    $sort_column = 'created_at';
}

// Validate sort order
$sort_order = strtoupper($sort_order) === 'ASC' ? 'ASC' : 'DESC';

$where = [];
$params = [];

if (!empty($username_filter)) {
    $where[] = "u.username LIKE ?";
    $params[] = '%' . $username_filter . '%';
}
if (!empty($start_date)) {
    $where[] = "DATE(l.created_at) >= ?";
    $params[] = $start_date;
}
if (!empty($end_date)) {
    $where[] = "DATE(l.created_at) <= ?";
    $params[] = $end_date;
}

$where_clause = $where ? "WHERE " . implode(" AND ", $where) : "";

try {
    // Count users
    $users_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE is_admin = FALSE");
    $users_stmt->execute();
    $total_users = $users_stmt->fetchColumn();

    // Count tasks
    $tasks_stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks");
    $tasks_stmt->execute();
    $total_tasks = $tasks_stmt->fetchColumn();

    // Count unread messages
    $messages_stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE status = 'unread'");
    $messages_stmt->execute();
    $unread_messages = $messages_stmt->fetchColumn();

    // Count total activity logs for pagination
    $count_sql = "SELECT COUNT(*) FROM activity_logs l JOIN users u ON l.user_id = u.id $where_clause";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_activity = $count_stmt->fetchColumn();
    $total_pages = ceil($total_activity / $per_page);

    // Fetch recent activity with pagination and sorting
    $sql = "
        SELECT l.*, u.username 
        FROM activity_logs l 
        JOIN users u ON l.user_id = u.id 
        $where_clause
        ORDER BY $sort_column $sort_order
        LIMIT $per_page OFFSET $offset
    ";
    $activity_stmt = $pdo->prepare($sql);
    $activity_stmt->execute($params);
    $recent_activity = $activity_stmt->fetchAll();
} catch (PDOException $e) {
    set_message('Error fetching dashboard data: ' . htmlspecialchars($e->getMessage()), 'danger');
    $total_users = $total_tasks = $unread_messages = $total_activity = 0;
    $total_pages = 1;
    $recent_activity = [];
}

// Function to generate sort link
function sort_link($column, $label)
{
    global $sort_column, $sort_order, $username_filter, $start_date, $end_date, $per_page;

    $new_order = ($sort_column === $column && $sort_order === 'DESC') ? 'ASC' : 'DESC';
    $query_params = [
        'username' => $username_filter,
        'start_date' => $start_date,
        'end_date' => $end_date,
        'per_page' => $per_page,
        'sort' => $column,
        'order' => $new_order
    ];

    $sort_icon = '';
    if ($sort_column === $column) {
        $sort_icon = $sort_order === 'ASC' ? ' <i class="fas fa-sort-up"></i>' : ' <i class="fas fa-sort-down"></i>';
    } else {
        $sort_icon = ' <i class="fas fa-sort"></i>';
    }

    return '<a href="?' . http_build_query($query_params) . '" class="text-decoration-none">' . $label . $sort_icon . '</a>';
}
?>

<div class="row">
    <!-- Cards Section -->
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Total Users</h5>
                    <h2 class="mb-0"><?php echo (int)$total_users; ?></h2>
                </div>
                <i class="fas fa-users fa-3x"></i>
            </div>
            <div class="card-footer bg-transparent">
                <a href="manage-users.php" class="text-white text-decoration-none stretched-link">View Users</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Total Tasks</h5>
                    <h2 class="mb-0"><?php echo (int)$total_tasks; ?></h2>
                </div>
                <i class="fas fa-tasks fa-3x"></i>
            </div>
            <div class="card-footer bg-transparent">
                <a href="#"
                    class="text-dark text-decoration-none stretched-link"
                    onclick="alert('🚫 This section contains user’s private data.\n\nYou are not supposed to view this information, as it involves personal privacy. Please avoid accessing it without permission.'); return false;">
                    View All task
                </a>
            </div>
        </div>
    </div>


    <div class="col-md-4 mb-4">
        <div class="card bg-warning text-dark">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title">Unread Messages</h5>
                    <h2 class="mb-0"><?php echo (int)$unread_messages; ?></h2>
                </div>
                <i class="fas fa-envelope fa-3x"></i>
            </div>
            <div class="card-footer bg-transparent">
                <a href="view-messages.php" class="text-dark text-decoration-none stretched-link">View Messages</a>
            </div>
        </div>
    </div>
</div>

<!-- Filter Form -->
<div class="card mb-4">
    <div class="card-header bg-light">
        <strong>Recent Activity Filter</strong>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="Search by username" value="<?php echo htmlspecialchars($username_filter); ?>">
            </div>
            <div class="col-md-2">
                <label for="start_date" class="form-label">From Date</label>
                <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($start_date); ?>">
            </div>
            <div class="col-md-2">
                <label for="end_date" class="form-label">To Date</label>
                <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($end_date); ?>">
            </div>
            <div class="col-md-3">
                <label for="per_page" class="form-label">Results Per Page</label>
                <select id="per_page" name="per_page" class="form-select">
                    <option value="5" <?php echo $per_page == 5 ? 'selected' : ''; ?>>5 per page</option>
                    <option value="10" <?php echo $per_page == 10 ? 'selected' : ''; ?>>10 per page</option>
                    <option value="15" <?php echo $per_page == 15 ? 'selected' : ''; ?>>15 per page</option>
                    <option value="20" <?php echo $per_page == 20 ? 'selected' : ''; ?>>20 per page</option>
                    <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50 per page</option>
                </select>
            </div>
            <div class="col-md-2 d-flex justify-content-start">
                <button type="submit" class="btn btn-primary px-4">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>


<!-- Recent Activity Table -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Recent Activity</h5>
        <div class="text-muted">
            Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + $per_page, $total_activity); ?> of <?php echo $total_activity; ?> records
        </div>
    </div>
    <div class="card-body">
        <?php if (empty($recent_activity)): ?>
            <p class="text-muted">No recent activity found.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo sort_link('username', 'User'); ?></th>
                            <th><?php echo sort_link('activity', 'Activity'); ?></th>
                            <th><?php echo sort_link('ip_address', 'IP Address'); ?></th>
                            <th><?php echo sort_link('created_at', 'Time'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_activity as $index => $activity): ?>
                            <tr>
                                <td><?php echo $offset + $index + 1; ?></td>
                                <td><?php echo htmlspecialchars($activity['username']); ?></td>
                                <td><?php echo htmlspecialchars($activity['activity']); ?></td>
                                <td><?php echo htmlspecialchars($activity['ip_address']); ?></td>
                                <td><?php echo date('M j, Y g:i A', strtotime($activity['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Activity pagination">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>"
                                    aria-label="First">
                                    <span aria-hidden="true">&laquo;&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>"
                                    aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php
                        // Show page numbers
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);

                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>"
                                    aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link"
                                    href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"
                                    aria-label="Last">
                                    <span aria-hidden="true">&raquo;&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>