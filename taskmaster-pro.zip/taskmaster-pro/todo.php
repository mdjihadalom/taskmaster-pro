<?php
$page_title = "Task Manager";
require_once 'includes/header.php';
require_login();
if ($_SESSION['is_admin'] != 0) {
    header("Location: admin-dashboard.php");
    exit();
}

// Handle task actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'])) {
        set_message('Invalid CSRF token', 'danger');
        header("Location: todo.php");
        exit();
    }

    if (isset($_POST['add_task'])) {
        // Add new task
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);

        try {
            $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, description) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $title, $description]);

            log_activity("Task added: $title");
            set_message('Task added successfully', 'success');
        } catch (PDOException $e) {
            set_message('Error adding task: ' . $e->getMessage(), 'danger');
        }
    } elseif (isset($_POST['update_task'])) {
        // Update existing task
        $task_id = (int)$_POST['task_id'];
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $status = sanitize($_POST['status']);

        try {
            $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, status = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
            $stmt->execute([$title, $description, $status, $task_id, $_SESSION['user_id']]);

            log_activity("Task updated: $title");
            set_message('Task updated successfully', 'success');
        } catch (PDOException $e) {
            set_message('Error updating task: ' . $e->getMessage(), 'danger');
        }
    } elseif (isset($_POST['delete_task'])) {
        // Delete task
        $task_id = (int)$_POST['task_id'];

        try {
            // Get task title for logging before deletion
            $stmt = $pdo->prepare("SELECT title FROM tasks WHERE id = ? AND user_id = ?");
            $stmt->execute([$task_id, $_SESSION['user_id']]);
            $task = $stmt->fetch();

            if ($task) {
                $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
                $stmt->execute([$task_id, $_SESSION['user_id']]);

                log_activity("Task deleted: " . $task['title']);
                set_message('Task deleted successfully', 'success');
            }
        } catch (PDOException $e) {
            set_message('Error deleting task: ' . $e->getMessage(), 'danger');
        }
    }

    header("Location: todo.php");
}

// Handle task status toggle (GET request)
if (isset($_GET['toggle_status'])) {
    $task_id = (int)$_GET['toggle_status'];

    try {
        // Get current status
        $stmt = $pdo->prepare("SELECT id, title, status FROM tasks WHERE id = ? AND user_id = ?");
        $stmt->execute([$task_id, $_SESSION['user_id']]);
        $task = $stmt->fetch();

        if ($task) {
            $new_status = $task['status'] === 'completed' ? 'pending' : 'completed';

            $stmt = $pdo->prepare("UPDATE tasks SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$new_status, $task_id]);

            log_activity("Task status toggled: " . $task['title'] . " ($new_status)");
            set_message('Task status updated', 'success');
        }
    } catch (PDOException $e) {
        set_message('Error updating task status: ' . $e->getMessage(), 'danger');
    }

    header("Location: todo.php");
}

// Get filter and search parameters
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : 'all';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$start_date = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : '';

// Pagination settings
$per_page = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Build query based on filter and search
$query = "SELECT * FROM tasks WHERE user_id = ?";
$count_query = "SELECT COUNT(*) FROM tasks WHERE user_id = ?";
$params = [$_SESSION['user_id']];
$count_params = [$_SESSION['user_id']];

if ($filter === 'completed') {
    $query .= " AND status = 'completed'";
    $count_query .= " AND status = 'completed'";
} elseif ($filter === 'pending') {
    $query .= " AND status = 'pending'";
    $count_query .= " AND status = 'pending'";
}

if (!empty($search)) {
    $query .= " AND (title LIKE ? OR description LIKE ?)";
    $count_query .= " AND (title LIKE ? OR description LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $count_params[] = $search_term;
    $count_params[] = $search_term;
}

// Date range filtering
if (!empty($start_date)) {
    $query .= " AND DATE(created_at) >= ?";
    $count_query .= " AND DATE(created_at) >= ?";
    $params[] = $start_date;
    $count_params[] = $start_date;
}

if (!empty($end_date)) {
    $query .= " AND DATE(created_at) <= ?";
    $count_query .= " AND DATE(created_at) <= ?";
    $params[] = $end_date;
    $count_params[] = $end_date;
}

$query .= " ORDER BY status, created_at DESC LIMIT $per_page OFFSET $offset";

// Fetch tasks
try {
    // Get total count for pagination
    $stmt = $pdo->prepare($count_query);
    $stmt->execute($count_params);
    $total_tasks = $stmt->fetchColumn();

    // Calculate total pages
    $total_pages = ceil($total_tasks / $per_page);

    // Get tasks for current page
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll();
} catch (PDOException $e) {
    set_message('Error fetching tasks: ' . $e->getMessage(), 'danger');
    $tasks = [];
    $total_tasks = 0;
    $total_pages = 1;
}

// Check if we're in add/edit mode
$edit_mode = false;
$current_task = null;

if (isset($_GET['action']) && $_GET['action'] === 'add') {
    // Prepare empty task for add form
    $current_task = [
        'id' => 0,
        'title' => '',
        'description' => '',
        'status' => 'pending'
    ];
} elseif (isset($_GET['edit'])) {
    $task_id = (int)$_GET['edit'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
        $stmt->execute([$task_id, $_SESSION['user_id']]);
        $current_task = $stmt->fetch();

        if ($current_task) {
            $edit_mode = true;
        } else {
            set_message('Task not found', 'danger');
            header("Location: todo.php");
            exit();
        }
    } catch (PDOException $e) {
        set_message('Error fetching task: ' . $e->getMessage(), 'danger');
        header("Location: todo.php");
        exit();
    }
}
?>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Task Manager</h5>
                <div>
                    <a href="todo.php?action=add" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus me-1"></i> Add Task
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if ($edit_mode || isset($_GET['action'])): ?>
                    <!-- Add/Edit Task Form -->
                    <form action="todo.php" method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        <input type="hidden" name="task_id" value="<?php echo $current_task['id']; ?>">

                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title"
                                value="<?php echo htmlspecialchars($current_task['title']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php
                                                                                                        echo htmlspecialchars($current_task['description']);
                                                                                                        ?></textarea>
                        </div>

                        <?php if ($edit_mode): ?>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="pending" <?php echo $current_task['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="completed" <?php echo $current_task['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                </select>
                            </div>

                            <div class="d-flex justify-content-between">
                                <button type="submit" name="update_task" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Update Task
                                </button>
                                <a href="todo.php" class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        <?php else: ?>
                            <div class="d-flex justify-content-between">
                                <button type="submit" name="add_task" class="btn btn-primary">
                                    <i class="fas fa-plus me-1"></i> Add Task
                                </button>
                                <a href="todo.php" class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        <?php endif; ?>
                    </form>
                <?php else: ?>
                    <!-- Task List with Filter and Search -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <form method="get" class="row g-3 align-items-end">
                                <!-- Filter Dropdown -->
                                <div class="col-md-2 col-sm-6">
                                    <label for="filter" class="form-label">Task Status</label>
                                    <select name="filter" id="filter" class="form-select">
                                        <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Tasks</option>
                                        <option value="pending" <?php echo $filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="completed" <?php echo $filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                </div>

                                <!-- Start Date -->
                                <div class="col-md-2 col-sm-6">
                                    <label for="start_date" class="form-label">From Date</label>
                                    <input type="date" id="start_date" name="start_date" class="form-control"
                                        value="<?php echo htmlspecialchars($start_date); ?>">
                                </div>

                                <!-- End Date -->
                                <div class="col-md-2 col-sm-6">
                                    <label for="end_date" class="form-label">To Date</label>
                                    <input type="date" id="end_date" name="end_date" class="form-control"
                                        value="<?php echo htmlspecialchars($end_date); ?>">
                                </div>

                                <!-- Items Per Page -->
                                <div class="col-md-2 col-sm-6">
                                    <label for="per_page" class="form-label">Items Per Page</label>
                                    <select name="per_page" id="per_page" class="form-select">
                                        <option value="5" <?php echo $per_page == 5 ? 'selected' : ''; ?>>5</option>
                                        <option value="10" <?php echo $per_page == 10 ? 'selected' : ''; ?>>10</option>
                                        <option value="15" <?php echo $per_page == 15 ? 'selected' : ''; ?>>15</option>
                                        <option value="20" <?php echo $per_page == 20 ? 'selected' : ''; ?>>20</option>
                                        <option value="50" <?php echo $per_page == 50 ? 'selected' : ''; ?>>50</option>
                                    </select>
                                </div>

                                <!-- Search -->
                                <div class="col-md-2 col-sm-6">
                                    <label for="search" class="form-label">Search</label>
                                    <div class="input-group">
                                        <input type="text" id="search" name="search" class="form-control" placeholder="Search tasks..."
                                            value="<?php echo htmlspecialchars($search); ?>">
                                        <button class="btn btn-outline-secondary" type="submit">
                                            <i class="fas fa-search"></i>
                                        </button>
                                        <?php if (!empty($search) || !empty($start_date) || !empty($end_date)): ?>
                                            <a href="todo.php?filter=<?php echo $filter; ?>&per_page=<?php echo $per_page; ?>" class="btn btn-outline-danger" title="Clear Filters">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="col-md-2 col-sm-6">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-filter"></i> Filter
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php if (empty($tasks)): ?>
                        <div class="alert alert-info">
                            No tasks found. <a href="todo.php?action=add" class="alert-link">Add a new task</a> to get started.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($tasks as $task): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($task['title']); ?></td>
                                            <td><?php echo nl2br(htmlspecialchars($task['description'])); ?></td>
                                            <td>
                                                <a href="todo.php?toggle_status=<?php echo $task['id']; ?>"
                                                    class="badge bg-<?php echo $task['status'] === 'completed' ? 'success' : 'warning'; ?> text-decoration-none">
                                                    <?php echo ucfirst($task['status']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($task['created_at'])); ?></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <a href="todo.php?edit=<?php echo $task['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form action="todo.php" method="post" onsubmit="return confirm('Are you sure you want to delete this task?');">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                                                        <button type="submit" name="delete_task" class="btn btn-sm btn-outline-danger">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                            <nav aria-label="Task pagination">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>"
                                                aria-label="First">
                                                <span aria-hidden="true">&laquo;&laquo;</span>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php
                                    // Show page numbers
                                    $start_page = max(1, $page - 2);
                                    $end_page = min($total_pages, $page + 2);

                                    for ($i = $start_page; $i <= $end_page; $i++): ?>
                                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                            <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>

                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>"
                                                aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link"
                                                href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"
                                                aria-label="Last">
                                                <span aria-hidden="true">&raquo;&raquo;</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>

                        <div class="text-muted text-center">
                            Showing <?php echo ($offset + 1); ?>-<?php echo min($offset + $per_page, $total_tasks); ?> of <?php echo $total_tasks; ?> tasks
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>