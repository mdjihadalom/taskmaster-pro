<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (is_logged_in()) {
    log_activity("User logged out");

    // Clear all session variables
    $_SESSION = [];

    // Destroy the session
    session_destroy();

    // Delete the session cookie to remove session ID from browser
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();

        $path = is_array($params['path']) ? implode('', $params['path']) : $params['path'];

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $path,
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
}

// Redirect to login page
header("Location: index.php");
exit();
