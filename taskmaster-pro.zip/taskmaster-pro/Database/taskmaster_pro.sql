-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 25, 2025 at 08:55 PM
-- Server version: 10.6.22-MariaDB
-- PHP Version: 8.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dreamcor_taskmaster_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `activity`, `ip_address`, `created_at`) VALUES
(91, 8, 'User logged in', '37.111.221.55', '2025-06-23 17:18:57'),
(92, 8, 'User logged out', '37.111.221.55', '2025-06-23 17:19:25'),
(93, 8, 'User logged in', '37.111.221.55', '2025-06-23 17:19:35'),
(94, 8, 'User logged out', '37.111.221.55', '2025-06-23 17:19:41'),
(95, 8, 'User logged in', '37.111.221.55', '2025-06-23 17:20:38'),
(96, 8, 'User logged out', '37.111.221.55', '2025-06-23 17:22:47'),
(97, 9, 'User logged in', '37.111.221.55', '2025-06-23 17:24:00'),
(98, 8, 'User logged in', '37.111.221.55', '2025-06-23 17:25:06'),
(99, 9, 'User logged in', '37.111.221.55', '2025-06-23 17:27:09'),
(100, 9, 'Task added: District Intranet Director', '37.111.221.55', '2025-06-23 17:27:55'),
(101, 9, 'Task added: Dynamic Group Designer', '37.111.221.55', '2025-06-23 17:28:08'),
(102, 9, 'Task added: Internal Marketing Engineer', '37.111.221.55', '2025-06-23 17:28:23'),
(103, 9, 'Task added: Legacy Optimization Facilitator', '37.111.221.55', '2025-06-23 17:28:36'),
(104, 9, 'Task status toggled: Legacy Optimization Facilitator (completed)', '37.111.221.55', '2025-06-23 17:32:05'),
(105, 9, 'User logged out', '37.111.221.55', '2025-06-23 18:43:42'),
(106, 8, 'User logged in', '37.111.221.55', '2025-06-23 18:43:53'),
(107, 8, 'User logged in', '37.111.221.180', '2025-06-23 19:36:47'),
(108, 9, 'User logged in', '37.111.221.55', '2025-06-23 19:50:31'),
(109, 9, 'User logged out', '37.111.221.55', '2025-06-23 19:50:34'),
(110, 9, 'User logged in', '37.111.221.55', '2025-06-23 19:51:35'),
(111, 9, 'Task deleted: Dynamic Group Designer', '37.111.221.55', '2025-06-23 19:51:54'),
(112, 9, 'User logged in', '37.111.221.180', '2025-06-23 19:55:13'),
(113, 9, 'Task status toggled: Internal Marketing Engineer (completed)', '37.111.221.180', '2025-06-23 20:05:14'),
(114, 9, 'Task status toggled: Legacy Optimization Facilitator (pending)', '37.111.221.180', '2025-06-23 20:05:18'),
(115, 9, 'User logged in', '37.111.221.55', '2025-06-23 20:06:06'),
(116, 9, 'User logged in', '37.111.221.55', '2025-06-23 20:06:24'),
(117, 8, 'User logged in', '37.111.221.55', '2025-06-23 20:08:32'),
(118, 8, 'User logged out', '37.111.221.55', '2025-06-23 20:17:10'),
(119, 9, 'User logged in', '37.111.221.55', '2025-06-23 20:17:18'),
(120, 9, 'User logged out', '37.111.221.55', '2025-06-23 20:18:18'),
(121, 8, 'User logged in', '37.111.221.55', '2025-06-23 20:18:36'),
(122, 8, 'User logged out', '37.111.221.55', '2025-06-23 20:19:19'),
(123, 9, 'User logged in', '37.111.221.55', '2025-06-23 20:22:55'),
(124, 9, 'User logged out', '37.111.221.55', '2025-06-23 20:38:31'),
(125, 8, 'User logged in', '37.111.221.55', '2025-06-23 20:47:18'),
(126, 8, 'User logged out', '37.111.221.55', '2025-06-23 21:05:31'),
(127, 9, 'User logged in', '37.111.221.55', '2025-06-23 21:05:39'),
(128, 9, 'User logged in', '37.111.221.181', '2025-06-23 21:13:35'),
(129, 9, 'User logged out', '37.111.221.181', '2025-06-23 21:14:25'),
(130, 8, 'User logged in', '37.111.221.181', '2025-06-23 21:14:40'),
(131, 8, 'User logged in', '37.111.218.251', '2025-06-24 02:53:31'),
(132, 8, 'User logged out', '37.111.218.251', '2025-06-24 02:55:09'),
(133, 9, 'User logged in', '37.111.218.251', '2025-06-24 02:55:22'),
(134, 8, 'User logged in', '37.111.218.251', '2025-06-24 03:34:15'),
(135, 8, 'User logged in', '37.111.218.251', '2025-06-24 07:55:07'),
(136, 8, 'User logged in', '37.111.218.251', '2025-06-24 12:07:48'),
(137, 8, 'User logged in', '37.111.218.251', '2025-06-24 12:08:36'),
(138, 8, 'User logged in', '37.111.218.32', '2025-06-25 12:25:33'),
(139, 8, 'User logged in', '37.111.218.61', '2025-06-26 00:04:09'),
(140, 8, 'User logged in', '37.111.218.100', '2025-06-26 00:47:39'),
(141, 8, 'User logged out', '37.111.218.100', '2025-06-26 00:48:09'),
(142, 8, 'User logged in', '37.111.218.61', '2025-06-26 00:50:52'),
(143, 9, 'User logged in', '37.111.218.100', '2025-06-26 00:52:46'),
(144, 9, 'Task added: Legacy Infrastructure Analyst', '37.111.218.100', '2025-06-26 00:53:03'),
(145, 9, 'Task added: Future Creative Orchestrator', '37.111.218.100', '2025-06-26 00:53:10'),
(146, 9, 'Task added: Senior Web Assistant', '37.111.218.100', '2025-06-26 00:53:16'),
(147, 9, 'Task added: Principal Research Producer', '37.111.218.100', '2025-06-26 00:53:24'),
(148, 9, 'Task status toggled: Future Creative Orchestrator (completed)', '37.111.218.100', '2025-06-26 00:53:38'),
(149, 9, 'User logged out', '37.111.218.100', '2025-06-26 00:54:44'),
(150, 8, 'User logged in', '37.111.218.100', '2025-06-26 00:54:54'),
(151, 8, 'User logged out', '37.111.218.100', '2025-06-26 00:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` enum('read','unread') DEFAULT 'unread',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `status`, `created_at`) VALUES
(3, 'user', 'jihadalom000@gmail.com', 'hi ! man', 'unread', '2025-06-23 17:30:49'),
(4, 'user', 'jihadalom000@gmail.com', 'This is test mesage', 'unread', '2025-06-23 17:31:50'),
(5, 'user', 'jihadalom000@gmail.com', 'test', 'unread', '2025-06-23 20:06:54'),
(6, 'user', 'jihadalom000@gmail.com', 'demo 01', 'unread', '2025-06-26 00:54:16'),
(7, 'user', 'jihadalom000@gmail.com', 'demo 02', 'unread', '2025-06-26 00:54:23'),
(8, 'user', 'jihadalom000@gmail.com', 'demo 03', 'unread', '2025-06-26 00:54:30');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `title`, `description`, `status`, `created_at`, `updated_at`) VALUES
(8, 9, 'District Intranet Director', 'Voluptatem quae exercitationem commodi ut velit voluptatibus assumenda earum ipsam.', 'pending', '2025-06-23 17:27:55', '2025-06-23 17:27:55'),
(10, 9, 'Internal Marketing Engineer', 'Maxime soluta similique praesentium.', 'completed', '2025-06-23 17:28:23', '2025-06-23 20:05:14'),
(11, 9, 'Legacy Optimization Facilitator', 'Iure dolores rerum enim perferendis nam perferendis.', 'pending', '2025-06-23 17:28:36', '2025-06-23 20:05:18'),
(12, 9, 'Legacy Infrastructure Analyst', 'Aliquam aperiam aliquam fuga sit ipsam.', 'pending', '2025-06-26 00:53:03', '2025-06-26 00:53:03'),
(13, 9, 'Future Creative Orchestrator', 'Consectetur assumenda non.', 'completed', '2025-06-26 00:53:10', '2025-06-26 00:53:38'),
(14, 9, 'Senior Web Assistant', 'Reiciendis quo corporis quibusdam praesentium.', 'pending', '2025-06-26 00:53:16', '2025-06-26 00:53:16'),
(15, 9, 'Principal Research Producer', 'Distinctio fugit aliquid.', 'pending', '2025-06-26 00:53:24', '2025-06-26 00:53:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `security_question` varchar(255) NOT NULL,
  `security_answer` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `security_question`, `security_answer`, `is_admin`, `created_at`) VALUES
(8, 'admin', 'jihadalom191@gmail.com', '$2y$10$lcJcUiZ.8bauxAqtDY2T.eScFm7UUq9Y8Yix3JGmWxmJs7O8Tkhkq', 'admin', 'What was your first pet&#039;s name?', '$2y$10$qQnjRVlRYxQ7UwjIBVSnDORxXli1DeNMPSKFMNod5jmZF/z4iC3fe', 1, '2025-06-23 17:16:55'),
(9, 'user', 'jihadalom000@gmail.com', '$2y$10$8v6M7oga0e4g6ts9isef7.apy.5L2sIjCyFv82vYRdvdYqLI7vYMq', 'user', 'What was your first pet&#039;s name?', '$2y$10$wJMB/xO7/8UUTgEbVL0t6uR6hObUhmkEc/2Bb.LqCmFYzcUHGqtoC', 0, '2025-06-23 17:23:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
