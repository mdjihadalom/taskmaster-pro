<?php
$page_title = "Forgot Password";
require_once 'includes/header.php';

if (is_logged_in()) {
    header("Location: dashboard.php");
    exit();
}

// Handle forgot password form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reset_request'])) {
        // Step 1: Request password reset
        $email = sanitize($_POST['email']);

        try {
            $stmt = $pdo->prepare("SELECT id, username, security_question FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                $_SESSION['reset_user_id'] = $user['id'];
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_username'] = $user['username'];
                $_SESSION['reset_question'] = $user['security_question'];

                header("Location: forgot-password.php?step=2");
                exit();
            } else {
                set_message('No account found with that email address', 'danger');
            }
        } catch (PDOException $e) {
            set_message('Error: ' . htmlspecialchars($e->getMessage()), 'danger');
        }
    } elseif (isset($_POST['verify_answer'])) {
        // Step 2: Verify security answer
        $answer = sanitize($_POST['security_answer']);

        try {
            $stmt = $pdo->prepare("SELECT security_answer FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['reset_user_id']]);
            $user = $stmt->fetch();

            if ($user && password_verify($answer, $user['security_answer'])) {
                $_SESSION['reset_verified'] = true;
                header("Location: forgot-password.php?step=3");
                exit();
            } else {
                set_message('Incorrect security answer', 'danger');
                header("Location: forgot-password.php?step=2");
                exit();
            }
        } catch (PDOException $e) {
            set_message('Error: ' . htmlspecialchars($e->getMessage()), 'danger');
            header("Location: forgot-password.php?step=2");
            exit();
        }
    } elseif (isset($_POST['update_password'])) {
        // Step 3: Update password
        $new_password = sanitize($_POST['new_password']);
        $confirm_password = sanitize($_POST['confirm_password']);

        if ($new_password !== $confirm_password) {
            set_message('Passwords do not match', 'danger');
            header("Location: forgot-password.php?step=3");
            exit();
        }

        if (strlen($new_password) < 8) {
            set_message('Password must be at least 8 characters long', 'danger');
            header("Location: forgot-password.php?step=3");
            exit();
        }

        try {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed_password, $_SESSION['reset_user_id']]);

            // Clear reset session variables
            unset($_SESSION['reset_user_id']);
            unset($_SESSION['reset_email']);
            unset($_SESSION['reset_username']);
            unset($_SESSION['reset_question']);
            unset($_SESSION['reset_verified']);

            set_message('Password updated successfully. You can now login with your new password.', 'success');
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            set_message('Error updating password: ' . htmlspecialchars($e->getMessage()), 'danger');
            header("Location: forgot-password.php?step=3");
            exit();
        }
    }
}

// Determine which step to show
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card shadow">
            <div class="card-body">
                <h2 class="card-title text-center mb-4">Password Recovery</h2>

                <?php if ($step === 1): ?>
                    <!-- Step 1: Request password reset -->
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                        <div class="mb-3">
                            <label for="email" class="form-label">Enter your email address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" name="reset_request" class="btn btn-primary">Continue</button>
                        </div>

                        <div class="text-center">
                            <a href="index.php" class="text-decoration-none">Back to Login</a>
                        </div>
                    </form>
                <?php elseif ($step === 2 && isset($_SESSION['reset_user_id'])): ?>
                    <!-- Step 2: Answer security question -->
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                        <div class="alert alert-info">
                            <p class="mb-1"><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['reset_username']); ?></p>
                            <p class="mb-0"><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['reset_email']); ?></p>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Security Question</label>
                            <p class="form-control-static fw-bold"><?php echo htmlspecialchars($_SESSION['reset_question']); ?></p>
                        </div>

                        <div class="mb-3">
                            <label for="security_answer" class="form-label">Your Answer</label>
                            <input type="text" class="form-control" id="security_answer" name="security_answer" required>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" name="verify_answer" class="btn btn-primary">Verify</button>
                            <a href="forgot-password.php" class="btn btn-outline-secondary">Start Over</a>
                        </div>
                    </form>
                <?php elseif ($step === 3 && isset($_SESSION['reset_verified'])): ?>
                    <!-- Step 3: Set new password -->
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

                        <div class="alert alert-info">
                            <p class="mb-1"><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['reset_username']); ?></p>
                            <p class="mb-0"><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['reset_email']); ?></p>
                        </div>

                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <small class="text-muted">Minimum 8 characters</small>
                        </div>

                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
                            <a href="forgot-password.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-danger">
                        Invalid request. Please start the password recovery process again.
                    </div>
                    <div class="text-center">
                        <a href="forgot-password.php" class="btn btn-primary">Start Over</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>